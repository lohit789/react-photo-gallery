const thumbnails = [
  {
    mainImage: 'https://img1.fpassets.com/is/image/FreePeople/39635362_010_0',
    imageAlt: '0'
  },
  {
    mainImage: 'https://img1.fpassets.com/is/image/FreePeople/39635362_010_a',
    imageAlt: 'A'
  },
  {
    mainImage: 'https://img1.fpassets.com/is/image/FreePeople/39635362_010_b',
    imageAlt: 'B'
  },
  {
    mainImage: 'https://img1.fpassets.com/is/image/FreePeople/39635362_010_c',
    imageAlt: 'C'
  },
  {
    mainImage: 'https://img1.fpassets.com/is/image/FreePeople/39635362_010_d',
    imageAlt: 'D'
  }
]
 
export default thumbnails
