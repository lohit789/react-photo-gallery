# Selection with custom ImageComponent
You can pass in your own component to the gallery via the ImageComponent prop. This would give you full control of what each individual image looks like in the Gallery. Here is an example of giving your gallery "Selection" capability.
<iframe src="https://codesandbox.io/embed/o7o241q09?hidenavigation=1&view=preview" style="width:100%; height:500px; border:0; border-radius: 4px; overflow:hidden;" sandbox="allow-modals allow-forms allow-popups allow-scripts allow-same-origin"></iframe>
