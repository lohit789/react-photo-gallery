# srcSet and sizes
Click preview button and Open dev tools > network tab to see which images the browser decides to call. Play with resizing the browser to see different image sizes fetched.
<iframe src="https://codesandbox.io/embed/zq0zlk423x?hidenavigation=1&view=editor" style="width:100%; height:500px; border:0; border-radius: 4px; overflow:hidden;" sandbox="allow-modals allow-forms allow-popups allow-scripts allow-same-origin"></iframe>
