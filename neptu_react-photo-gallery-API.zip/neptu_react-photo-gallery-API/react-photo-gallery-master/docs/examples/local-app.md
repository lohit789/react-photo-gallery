There is an example app that comes with the project.



```
npm install
npm start
```



Navigate to localhost:8000 in a browser.
```
```
