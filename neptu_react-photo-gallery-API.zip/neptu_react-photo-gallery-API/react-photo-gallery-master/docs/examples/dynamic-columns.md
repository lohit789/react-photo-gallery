# Dynamic Columns
Change the columns depending on the size of your container at breakpoints of your choosing. Here I am using [react-measure] to achieve this. Resize the browser to see this in action. 
<iframe src="https://codesandbox.io/embed/ll7ym48027?hidenavigation=1&view=editor" style="width:100%; height:500px; border:0; border-radius: 4px; overflow:hidden;" sandbox="allow-modals allow-forms allow-popups allow-scripts allow-same-origin"></iframe>


