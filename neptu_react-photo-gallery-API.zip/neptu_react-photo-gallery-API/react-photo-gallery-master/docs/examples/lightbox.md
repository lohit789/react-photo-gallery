# Using a Lightbox Component

This example uses [react-images] lightbox component.

<iframe src="https://codesandbox.io/embed/5vn3lvz2n4?hidenavigation=1&view=preview" style="width:100%; height:500px; border:0; border-radius: 4px; overflow:hidden;" sandbox="allow-modals allow-forms allow-popups allow-scripts allow-same-origin"></iframe>
